export class Role{
    RoleId:number;
    RoleName: string;
}