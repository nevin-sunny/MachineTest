export class Jwtresponse {
    UserName: string;
    RoleId:number;
    token:string;
    UserPassword:string;
}
