export class EmployeeRegistration {
    EmpId:number=0;
    FirstName:string='';
    LastName:string='';
    Gender:string='';
    Address:string='';
    PhoneNumber:number=0;
    UserId:number=0;
    Age:number=0;
}
