import { Travelrequest } from './travelrequest';

describe('Travelrequest', () => {
  it('should create an instance', () => {
    expect(new Travelrequest()).toBeTruthy();
  });
});
