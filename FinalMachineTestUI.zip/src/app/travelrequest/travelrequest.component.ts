import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-travelrequest',
  templateUrl: './travelrequest.component.html',
  styleUrls: ['./travelrequest.component.css']
})
export class TravelrequestComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
