import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-requestlist',
  templateUrl: './requestlist.component.html',
  styleUrls: ['./requestlist.component.css']
})
export class RequestlistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
